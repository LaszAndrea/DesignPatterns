package factory;

public interface Coffee{
    String prepare();
    String description();
    int cost();
}