package command;

public class CoffeeMachine {

    public String start() {
        return "\nCoffee machine started...";
    }
    
    public String stop() {
        return "\nCoffee machine stopped...";
    }

    public String clean() {
        return "\nCleaning coffee machine...";
    }

    public String saveOrder() {
        return "\nSaved the order...";
    }

}
