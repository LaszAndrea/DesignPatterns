package command;

import service.OrderService;

public class SaveOrderCommand implements Command {
    
    private CoffeeMachine machine;

    private OrderService orderService;
    private String coffeeType;
    private double price;

    public SaveOrderCommand(OrderService orderService, String coffeeType, double price, CoffeeMachine machine) {
        this.orderService = orderService;
        this.coffeeType = coffeeType;
        this.price = price;
        this.machine = machine; 
    }

    @Override
    public String execute() {
        orderService.saveOrder(coffeeType, price);
        return machine.saveOrder();
    }
}

