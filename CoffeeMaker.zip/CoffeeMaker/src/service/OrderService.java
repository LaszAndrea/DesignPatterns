package service;

import java.sql.*;

public class OrderService {
    private static final String DB_URL = "jdbc:sqlite:coffee.db";

    public OrderService() {
        createTableIfNotExists();
    }

    private void createTableIfNotExists() {
        String sql = """
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                coffee_type TEXT NOT NULL,
                price REAL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        """;

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.execute();
            System.out.println("Table 'orders' checked/created.");
        } catch (SQLException e) {
            System.out.println("Error creating table: " + e.getMessage());
        }
    }

    public void saveOrder(String coffeeType, double price) {
        String sql = "INSERT INTO orders(coffee_type, price) VALUES(?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, coffeeType);
            pstmt.setDouble(2, price);
            pstmt.executeUpdate();

            System.out.println("Order saved: " + coffeeType);
        } catch (SQLException e) {
            System.out.println("Error saving order: " + e.getMessage());
        }
    }
}

