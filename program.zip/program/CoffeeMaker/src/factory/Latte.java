package factory;

public class Latte implements Coffee{

    @Override
    public void prepare() {
        System.out.println("Latte készítése folyamatban...\n");
    }
    
}
