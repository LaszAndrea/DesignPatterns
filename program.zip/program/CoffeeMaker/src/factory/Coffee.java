package factory;

public interface Coffee{
    void prepare();
}