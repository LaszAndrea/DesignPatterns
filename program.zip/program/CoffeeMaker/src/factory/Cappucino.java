package factory;

public class Cappucino implements Coffee{

    @Override
    public void prepare() {
        System.out.println("Cappucino készítése folyamatban...\n");
    }
    
}
