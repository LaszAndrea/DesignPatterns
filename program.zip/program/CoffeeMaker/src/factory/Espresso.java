package factory;

public class Espresso implements Coffee {

    @Override
    public void prepare() {
        System.out.println("Espresso készítése folyamatban...\n");
    }

}