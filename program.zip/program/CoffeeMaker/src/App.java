import command.*;
import decorator.*;
import factory.*;

public class App {
    public static void main(String[] args) {
        
        // --- Factory Method ---
        Coffee espresso = MakeCoffee.createCoffee("espresso");
        Coffee latte = MakeCoffee.createCoffee("latte");
        espresso.prepare();
        latte.prepare();

        // --- Decorator ---
        Coffee moreMilkLatte = new WithMilk(latte);
        moreMilkLatte.prepare();

        System.out.println();

        // --- Command ---
        CoffeeMachine machine = new CoffeeMachine();
        CoffeeInvoker invoker = new CoffeeInvoker();

        invoker.setCommand(new StartCommand(machine));
        invoker.pressButton();

        invoker.setCommand(new CleanCommand(machine));
        invoker.pressButton();

        invoker.setCommand(new StopCommand(machine));
        invoker.pressButton();
    }
}
