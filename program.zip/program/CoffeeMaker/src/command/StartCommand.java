package command;

public class StartCommand implements Command {

    private CoffeeMachine machine;

    public StartCommand(CoffeeMachine machine) { 
        this.machine = machine; 
    }
    
    public void execute() { machine.start(); }
    
}
