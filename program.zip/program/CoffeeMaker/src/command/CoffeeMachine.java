package command;

public class CoffeeMachine {

    public void start() {
        System.out.println("Kávéfőző beindítva...");
    }
    
    public void stop() {
        System.out.println("Kávéfőző leállítva...");
    }

    public void clean() {
        System.out.println("Kávéfőző tisztítása...");
    }

}
