package decorator;

import factory.*;

abstract class PlusElements implements Coffee {

    protected Coffee decoratedCoffee;

    public PlusElements(Coffee coffee) {
        this.decoratedCoffee = coffee;
    }

    @Override
    public void prepare() {
        decoratedCoffee.prepare();
    }
    
}
