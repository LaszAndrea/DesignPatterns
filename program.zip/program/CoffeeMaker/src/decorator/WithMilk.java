package decorator;

import factory.*;

public class WithMilk extends PlusElements {
    
    public WithMilk(Coffee coffee) {
        super(coffee);
    }

    public void prepare() {
        super.prepare();
        System.out.println(" + Tej hozzáadva");
    }

}
